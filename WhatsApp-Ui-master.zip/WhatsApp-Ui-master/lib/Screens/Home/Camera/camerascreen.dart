import 'package:flutter/material.dart';

class CameraScreen extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(child: Text("Camera"),),
    );
  }

}