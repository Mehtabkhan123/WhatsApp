package com.example.whatsapp_series

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
